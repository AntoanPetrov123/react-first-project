const urls = {
    signInAuthentication: 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCCPh4cwZaL0tHRX8P91m5cRQ5DJhklFbc',
    signUpAuthentication: 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCCPh4cwZaL0tHRX8P91m5cRQ5DJhklFbc',
    users: 'https://change-your-car-react-default-rtdb.firebaseio.com/users.json',
    cars: 'https://change-your-car-react-default-rtdb.firebaseio.com/cars.json'
};

export default urls;