import CreateCarPostForm from "./CreateCarPostForm";

const NewPost = () => {
    // const addPostHandler = postData => {

    // };

    return(
        <CreateCarPostForm />
    );
};

export default NewPost;