// import classes from './Card.module.css';
const CardProfile = props => {
    return (
    <div>
        {props.children}
    </div>
    );
};

export default CardProfile;